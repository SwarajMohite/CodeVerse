'use client'

import { useState } from 'react'

const questions = [
  {
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correctAnswer: "Paris"
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correctAnswer: "Mars"
  },
  {
    question: "What is the largest mammal in the world?",
    options: ["African Elephant", "Blue Whale", "Giraffe", "Hippopotamus"],
    correctAnswer: "Blue Whale"
  }
]

export default function InteractiveLearning() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [showScore, setShowScore] = useState(false)

  const handleAnswerClick = (selectedAnswer) => {
    if (selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    const nextQuestion = currentQuestion + 1
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion)
    } else {
      setShowScore(true)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12">Interactive Learning</h1>
        <div className="max-w-2xl mx-auto bg-purple-800 rounded-lg p-8">
          {showScore ? (
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-4">Quiz Completed!</h2>
              <p className="text-2xl">You scored {score} out of {questions.length}</p>
              <button
                onClick={() => {
                  setCurrentQuestion(0)
                  setScore(0)
                  setShowScore(false)
                }}
                className="mt-8 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded transition duration-300"
              >
                Restart Quiz
              </button>
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-bold mb-4">Question {currentQuestion + 1}</h2>
              <p className="text-xl mb-8">{questions[currentQuestion].question}</p>
              <div className="space-y-4">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerClick(option)}
                    className="w-full text-left bg-purple-700 hover:bg-purple-600 p-4 rounded transition duration-300"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

