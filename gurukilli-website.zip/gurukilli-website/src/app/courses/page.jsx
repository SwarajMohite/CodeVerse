'use client'

import { useState } from 'react'
import Image from 'next/image'

const courses = [
  { name: 'Mathematics', image: '/math.jpg', topics: 20 },
  { name: 'Science', image: '/science.jpg', topics: 25 },
  { name: 'Social Studies', image: '/social-studies.jpg', topics: 18 },
  { name: 'English', image: '/english.jpg', topics: 22 },
  { name: 'Computer Science', image: '/computer-science.jpg', topics: 15 },
  { name: 'Art & Music', image: '/art-music.jpg', topics: 12 },
]

export default function Courses() {
  const [selectedCourse, setSelectedCourse] = useState(null)

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12">Our Courses</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course) => (
            <div
              key={course.name}
              className="bg-purple-800 rounded-lg overflow-hidden shadow-lg cursor-pointer transform transition-all duration-300 hover:scale-105"
              onClick={() => setSelectedCourse(course)}
            >
              <Image
                src={course.image}
                alt={course.name}
                width={400}
                height={300}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-2">{course.name}</h2>
                <p className="text-purple-200">{course.topics} topics</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {selectedCourse && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-purple-800 rounded-lg p-8 max-w-md">
            <h2 className="text-2xl font-bold mb-4">{selectedCourse.name}</h2>
            <p className="mb-4">This course contains {selectedCourse.topics} exciting topics to explore!</p>
            <button
              className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded"
              onClick={() => setSelectedCourse(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

