import Image from 'next/image'

const features = [
  {
    title: 'Gamified Learning',
    description: 'Earn points, badges, and climb leaderboards as you learn.',
    image: '/gamified-learning.jpg',
  },
  {
    title: 'AI Study Buddy',
    description: 'Get personalized help and answers to your questions 24/7.',
    image: '/ai-study-buddy.jpg',
  },
  {
    title: 'Interactive Quizzes',
    description: 'Test your knowledge with fun, engaging quizzes.',
    image: '/interactive-quizzes.jpg',
  },
  {
    title: 'Virtual Classrooms',
    description: 'Attend live classes and interact with teachers in real-time.',
    image: '/virtual-classrooms.jpg',
  },
]

export default function Features() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12">Our Features</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="bg-purple-800 rounded-lg overflow-hidden shadow-lg">
              <Image
                src={feature.image}
                alt={feature.title}
                width={600}
                height={400}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-2">{feature.title}</h2>
                <p className="text-purple-200">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

