import FeatureSection from '../components/feature-section'

const features = [
  {
    title: 'Peer-to-Peer Tutorials',
    description: 'Learn from your classmates and share your knowledge with others.',
    image: '/peer-tutorials.jpg',
  },
  {
    title: 'Gamified Learning',
    description: 'Earn badges, climb leaderboards, and make learning fun!',
    image: '/gamified-learning.jpg',
  },
  {
    title: 'Real-Time Quizzes and Polling',
    description: 'Engage in interactive sessions and get instant feedback.',
    image: '/real-time-quizzes.jpg',
  },
  {
    title: 'AI Chatbot',
    description: 'Get 24/7 study assistance from our intelligent AI companion.',
    image: '/ai-chatbot.jpg',
  },
  {
    title: 'Virtual Classrooms',
    description: 'Attend live sessions and interact with teachers in real-time.',
    image: '/virtual-classrooms.jpg',
  },
  {
    title: 'Mindfulness Exercises',
    description: 'Take breaks and recharge with guided relaxation techniques.',
    image: '/mindfulness.jpg',
  },
]

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold mb-12 text-center">Gurukilli Features</h1>
        {features.map((feature, index) => (
          <FeatureSection
            key={feature.title}
            title={feature.title}
            description={feature.description}
            image={feature.image}
            reverse={index % 2 !== 0}
          />
        ))}
      </div>
    </div>
  )
}

