'use client'

import { useState } from 'react'
import SubjectCard from '../components/subject-card'
import VirtualClassrooms from '../components/virtual-classrooms'

const subjects = [
  { name: 'Mathematics', progress: 75, image: '/math-bg.jpg' },
  { name: 'Science', progress: 60, image: '/science-bg.jpg' },
  { name: 'Social Science', progress: 80, image: '/social-bg.jpg' },
  { name: 'Languages', progress: 90, image: '/language-bg.jpg' },
  { name: 'Computer Applications', progress: 70, image: '/computer-bg.jpg' },
  { name: 'Environmental Studies', progress: 85, image: '/environment-bg.jpg' },
]

export default function CoursesPage() {
  const [activeTab, setActiveTab] = useState('subjects')

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold mb-12 text-center">Courses</h1>
        <div className="flex justify-center mb-8">
          <button
            className={`px-4 py-2 rounded-l-full ${activeTab === 'subjects' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('subjects')}
          >
            Subjects
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'tools' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('tools')}
          >
            Interactive Tools
          </button>
          <button
            className={`px-4 py-2 rounded-r-full ${activeTab === 'classrooms' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('classrooms')}
          >
            Virtual Classrooms
          </button>
        </div>
        {activeTab === 'subjects' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {subjects.map((subject) => (
              <SubjectCard key={subject.name} subject={subject} />
            ))}
          </div>
        )}
        {activeTab === 'tools' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
              <h3 className="text-2xl font-bold mb-4">Gamified Quizzes</h3>
              <p className="mb-4">Test your knowledge with fun, interactive quizzes.</p>
              <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Start Quiz
            </button>
          </div>
          <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Flashcards</h3>
            <p className="mb-4">Review key concepts with interactive flashcards.</p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Create Flashcards
            </button>
          </div>
          <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Peer-to-Peer Tutorials</h3>
            <p className="mb-4">Learn from and teach your classmates.</p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Explore Tutorials
            </button>
          </div>
          <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Project Zone</h3>
            <p className="mb-4">Work on cross-disciplinary projects and activities.</p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Start Project
            </button>
          </div>
        </div>
        )}
        {activeTab === 'classrooms' && <VirtualClassrooms />}
      </div>
    </div>
  )
}

