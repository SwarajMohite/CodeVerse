'use client'

import { useState } from 'react'
import QuizSection from '../components/quiz-section'
import FlashcardSection from '../components/flashcard-section'
import LeaderboardSection from '../components/leaderboard-section'

export default function InteractiveLearningPage() {
  const [activeTab, setActiveTab] = useState('quiz')

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold mb-12 text-center">Interactive Learning</h1>
        <div className="flex justify-center mb-8">
          <button
            className={`px-4 py-2 rounded-l-full ${activeTab === 'quiz' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('quiz')}
          >
            Multiplayer Quiz
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'flashcards' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('flashcards')}
          >
            Flashcards
          </button>
          <button
            className={`px-4 py-2 rounded-r-full ${activeTab === 'leaderboard' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('leaderboard')}
          >
            Leaderboard
          </button>
        </div>
        {activeTab === 'quiz' && <QuizSection />}
        {activeTab === 'flashcards' && <FlashcardSection />}
        {activeTab === 'leaderboard' && <LeaderboardSection />}
      </div>
    </div>
  )
}

