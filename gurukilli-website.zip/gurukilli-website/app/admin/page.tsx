'use client'

import { useState } from 'react'
import CourseManagement from '../components/course-management'
import AnalyticsDashboard from '../components/analytics-dashboard'

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('courses')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === '2812') {
      setIsAuthenticated(true)
    } else {
      alert('Incorrect password')
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white flex items-center justify-center">
        <form onSubmit={handleLogin} className="bg-purple-800 rounded-lg p-8 shadow-lg">
          <h1 className="text-3xl font-bold mb-6 text-center">Admin Login</h1>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="w-full bg-purple-700 text-white rounded-lg px-4 py-2 mb-4 focus:outline-none"
          />
          <button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out"
          >
            Login
          </button>
        </form>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold mb-12 text-center">Admin Dashboard</h1>
        <div className="flex justify-center mb-8">
          <button
            className={`px-4 py-2 rounded-l-full ${activeTab === 'courses' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('courses')}
          >
            Course Management
          </button>
          <button
            className={`px-4 py-2 rounded-r-full ${activeTab === 'analytics' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('analytics')}
          >
            Analytics
          </button>
        </div>
        {activeTab === 'courses' && <CourseManagement />}
        {activeTab === 'analytics' && <AnalyticsDashboard />}
      </div>
    </div>
  )
}

