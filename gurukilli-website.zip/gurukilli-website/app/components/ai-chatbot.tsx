'use client'

import { useState } from 'react'
import { Send } from 'lucide-react'

export default function AIChatbot() {
  const [messages, setMessages] = useState([
    { text: "Hello! I'm your AI study buddy. How can I help you today?", sender: 'bot' },
  ])
  const [input, setInput] = useState('')

  const handleSendMessage = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, sender: 'user' }])
      setInput('')
      // Simulate AI response (replace with actual AI integration)
      setTimeout(() => {
        setMessages((prevMessages) => [
          ...prevMessages,
          { text: "I'm processing your question. Give me a moment!", sender: 'bot' },
        ])
      }, 1000)
    }
  }

  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg h-[600px] flex flex-col">
      <h2 className="text-2xl font-bold mb-4">AI Study Buddy</h2>
      <div className="flex-grow overflow-y-auto mb-4 space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`p-2 rounded-lg ${
              message.sender === 'user' ? 'bg-purple-600 ml-auto' : 'bg-purple-700'
            } max-w-[70%]`}
          >
            {message.text}
          </div>
        ))}
      </div>
      <div className="flex">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me anything..."
          className="flex-grow bg-purple-700 text-white rounded-l-lg px-4 py-2 focus:outline-none"
        />
        <button
          onClick={handleSendMessage}
          className="bg-purple-600 hover:bg-purple-700 text-white rounded-r-lg px-4 py-2 transition duration-300 ease-in-out"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  )
}

