const recommendedTopics = [
  { name: 'Algebra: Quadratic Equations', subject: 'Mathematics' },
  { name: 'Cell Biology: Mitosis and Meiosis', subject: 'Science' },
  { name: 'World War II: Causes and Effects', subject: 'Social Science' },
]

export default function RecommendedTopics() {
  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Recommended Topics</h2>
      <div className="space-y-4">
        {recommendedTopics.map((topic) => (
          <div key={topic.name} className="bg-purple-700 rounded-lg p-4">
            <h3 className="text-lg font-semibold">{topic.name}</h3>
            <p className="text-sm text-purple-300">{topic.subject}</p>
            <button className="mt-2 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Start Learning
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

