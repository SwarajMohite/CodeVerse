import { Trophy, Star, Award } from 'lucide-react'

const achievements = [
  { name: 'Math Master', description: 'Completed all math modules', icon: Trophy },
  { name: 'Science Whiz', description: 'Aced 5 science quizzes in a row', icon: Star },
  { name: 'History Buff', description: 'Completed 10 history lessons', icon: Award },
]

export default function ProgressTracker() {
  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Your Achievements</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => (
          <div key={achievement.name} className="bg-purple-700 rounded-lg p-4 flex items-center">
            <achievement.icon className="w-12 h-12 mr-4 text-yellow-400" />
            <div>
              <h3 className="text-lg font-semibold">{achievement.name}</h3>
              <p className="text-sm text-purple-300">{achievement.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

