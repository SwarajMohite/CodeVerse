import Image from 'next/image'

interface FeatureSectionProps {
  title: string
  description: string
  image: string
  reverse?: boolean
}

export default function FeatureSection({ title, description, image, reverse = false }: FeatureSectionProps) {
  return (
    <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center mb-24`}>
      <div className="md:w-1/2 mb-8 md:mb-0">
        <Image
          src={image}
          alt={title}
          width={600}
          height={400}
          className="rounded-lg shadow-lg"
        />
      </div>
      <div className="md:w-1/2 md:px-8">
        <h2 className="text-3xl font-bold mb-4">{title}</h2>
        <p className="text-lg mb-6">{description}</p>
        <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
          Learn More
        </button>
      </div>
    </div>
  )
}

