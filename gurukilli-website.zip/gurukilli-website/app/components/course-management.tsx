'use client'

import { useState } from 'react'

const initialCourses = [
  { id: 1, name: 'Mathematics', topics: 20 },
  { id: 2, name: 'Science', topics: 25 },
  { id: 3, name: 'Social Science', topics: 18 },
]

export default function CourseManagement() {
  const [courses, setCourses] = useState(initialCourses)
  const [newCourseName, setNewCourseName] = useState('')

  const handleAddCourse = () => {
    if (newCourseName.trim()) {
      const newCourse = {
        id: courses.length + 1,
        name: newCourseName,
        topics: 0,
      }
      setCourses([...courses, newCourse])
      setNewCourseName('')
    }
  }

  const handleRemoveCourse = (id: number) => {
    setCourses(courses.filter((course) => course.id !== id))
  }

  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Course Management</h2>
      <div className="mb-6">
        <input
          type="text"
          value={newCourseName}
          onChange={(e) => setNewCourseName(e.target.value)}
          placeholder="Enter new course name"
          className="bg-purple-700 text-white rounded-lg px-4 py-2 mr-2 focus:outline-none"
        />
        <button
          onClick={handleAddCourse}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out"
        >
          Add Course
        </button>
      </div>
      <div className="space-y-4">
        {courses.map((course) => (
          <div key={course.id} className="bg-purple-700 rounded-lg p-4 flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">{course.name}</h3>
              <p className="text-sm text-purple-300">{course.topics} topics</p>
            </div>
            <button
              onClick={() => handleRemoveCourse(course.id)}
              className="bg-red-600 hover:bg-red-700 text-white font-bold py-1 px-3 rounded-full transition duration-300 ease-in-out"
            >
              Remove
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

