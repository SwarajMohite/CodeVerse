'use client'

import { useState } from 'react'

const flashcards = [
  {
    question: 'What is the capital of Japan?',
    answer: 'Tokyo',
  },
  {
    question: 'Who wrote "Romeo and Juliet"?',
    answer: 'William Shakespeare',
  },
  {
    question: 'What is the chemical symbol for gold?',
    answer: 'Au',
  },
]

export default function FlashcardSection() {
  const [currentCard, setCurrentCard] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)

  const handleNextCard = () => {
    setCurrentCard((prev) => (prev + 1) % flashcards.length)
    setIsFlipped(false)
  }

  const handlePrevCard = () => {
    setCurrentCard((prev) => (prev - 1 + flashcards.length) % flashcards.length)
    setIsFlipped(false)
  }

  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Flashcards</h2>
      <div
        className={`bg-purple-700 rounded-lg p-6 mb-4 h-64 flex items-center justify-center cursor-pointer transition-transform duration-500 transform ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
        onClick={() => setIsFlipped(!isFlipped)}
      >
        <div className="text-2xl font-semibold text-center">
          {isFlipped ? flashcards[currentCard].answer : flashcards[currentCard].question}
        </div>
      </div>
      <div className="flex justify-between">
        <button
          onClick={handlePrevCard}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
        >
          Previous
        </button>
        <button
          onClick={handleNextCard}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
        >
          Next
        </button>
      </div>
    </div>
  )
}

