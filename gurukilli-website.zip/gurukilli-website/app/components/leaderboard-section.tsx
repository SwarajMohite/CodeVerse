const leaderboardData = [
  { name: 'Alice', score: 1250, badge: '🏆' },
  { name: 'Bob', score: 1100, badge: '🥈' },
  { name: 'Charlie', score: 950, badge: '🥉' },
  { name: 'David', score: 800, badge: '🎖️' },
  { name: 'Eve', score: 750, badge: '🎖️' },
]

export default function LeaderboardSection() {
  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Leaderboard</h2>
      <table className="w-full">
        <thead>
          <tr className="text-left">
            <th className="py-2">Rank</th>
            <th>Name</th>
            <th>Score</th>
            <th>Badge</th>
          </tr>
        </thead>
        <tbody>
          {leaderboardData.map((player, index) => (
            <tr key={player.name} className="border-t border-purple-700">
              <td className="py-2">{index + 1}</td>
              <td>{player.name}</td>
              <td>{player.score}</td>
              <td>{player.badge}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

