import Image from 'next/image'

const enrolledCourses = [
  { name: 'Mathematics', progress: 75, image: '/math-bg.jpg' },
  { name: 'Science', progress: 60, image: '/science-bg.jpg' },
  { name: 'Social Science', progress: 80, image: '/social-bg.jpg' },
]

export default function EnrolledCourses() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {enrolledCourses.map((course) => (
        <div key={course.name} className="bg-purple-800 rounded-lg overflow-hidden shadow-lg">
          <div className="relative h-48">
            <Image
              src={course.image}
              alt={course.name}
              layout="fill"
              objectFit="cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <h3 className="text-2xl font-bold text-white">{course.name}</h3>
            </div>
          </div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-semibold">Progress</span>
              <span className="text-lg font-semibold">{course.progress}%</span>
            </div>
            <div className="w-full bg-purple-200 rounded-full h-2.5">
              <div
                className="bg-purple-600 h-2.5 rounded-full"
                style={{ width: `${course.progress}%` }}
              ></div>
            </div>
            <button className="mt-6 w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
              Continue Learning
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

