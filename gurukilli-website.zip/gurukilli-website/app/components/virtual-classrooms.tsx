'use client'

import { useState } from 'react'
import { Calendar } from '@/components/ui/calendar'

export default function VirtualClassrooms() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h3 className="text-2xl font-bold mb-4">Virtual Classrooms</h3>
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/2">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border"
          />
        </div>
        <div className="md:w-1/2">
          <h4 className="text-xl font-semibold mb-4">Upcoming Classes</h4>
          <ul className="space-y-4">
            <li className="bg-purple-700 rounded-lg p-4">
              <h5 className="font-semibold">Mathematics: Trigonometry</h5>
              <p>Date: May 15, 2024</p>
              <p>Time: 10:00 AM - 11:30 AM</p>
              <button className="mt-2 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
                Join Now
              </button>
            </li>
            <li className="bg-purple-700 rounded-lg p-4">
              <h5 className="font-semibold">Science: Chemical Reactions</h5>
              <p>Date: May 16, 2024</p>
              <p>Time: 2:00 PM - 3:30 PM</p>
              <button className="mt-2 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
                Join Now
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

