import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'

const data = [
  { name: 'Jan', students: 400, engagement: 240 },
  { name: 'Feb', students: 300, engagement: 139 },
  { name: 'Mar', students: 200, engagement: 980 },
  { name: 'Apr', students: 278, engagement: 390 },
  { name: 'May', students: 189, engagement: 480 },
  { name: 'Jun', students: 239, engagement: 380 },
]

export default function AnalyticsDashboard() {
  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Analytics Dashboard</h2>
      <div className="h-96">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="students" stroke="#8884d8" activeDot={{ r: 8 }} />
            <Line type="monotone" dataKey="engagement" stroke="#82ca9d" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

