'use client'

import { useState, useEffect } from 'react'

const questions = [
  {
    question: 'What is the capital of France?',
    options: ['London', 'Berlin', 'Paris', 'Madrid'],
    correctAnswer: 'Paris',
  },
  {
    question: 'Which planet is known as the Red Planet?',
    options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
    correctAnswer: 'Mars',
  },
  {
    question: 'What is the largest mammal in the world?',
    options: ['African Elephant', 'Blue Whale', 'Giraffe', 'Hippopotamus'],
    correctAnswer: 'Blue Whale',
  },
]

export default function QuizSection() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState('')
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(15)
  const [quizEnded, setQuizEnded] = useState(false)

  useEffect(() => {
    if (timeLeft > 0 && !quizEnded) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !quizEnded) {
      handleNextQuestion()
    }
  }, [timeLeft, quizEnded])

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer)
  }

  const handleNextQuestion = () => {
    if (selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer('')
      setTimeLeft(15)
    } else {
      setQuizEnded(true)
    }
  }

  if (quizEnded) {
    return (
      <div className="bg-purple-800 rounded-lg p-6 shadow-lg text-center">
        <h2 className="text-3xl font-bold mb-4">Quiz Completed!</h2>
        <p className="text-2xl mb-4">Your score: {score} / {questions.length}</p>
        <button
          onClick={() => {
            setCurrentQuestion(0)
            setSelectedAnswer('')
            setScore(0)
            setTimeLeft(15)
            setQuizEnded(false)
          }}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
        >
          Restart Quiz
        </button>
      </div>
    )
  }

  return (
    <div className="bg-purple-800 rounded-lg p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Question {currentQuestion + 1}</h2>
      <p className="text-lg mb-4">{questions[currentQuestion].question}</p>
      <div className="grid grid-cols-2 gap-4 mb-6">
        {questions[currentQuestion].options.map((option) => (
          <button
            key={option}
            onClick={() => handleAnswerSelect(option)}
            className={`p-2 rounded-lg ${
              selectedAnswer === option ? 'bg-purple-600' : 'bg-purple-700'
            } hover:bg-purple-600 transition duration-300`}
          >
            {option}
          </button>
        ))}
      </div>
      <div className="flex justify-between items-center">
        <p className="text-lg">Time left: {timeLeft} seconds</p>
        <button
          onClick={handleNextQuestion}
          disabled={!selectedAnswer}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next Question
        </button>
      </div>
    </div>
  )
}

