import { Play } from 'lucide-react'
import Image from 'next/image'

export default function HeroSection() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <video
        autoPlay
        loop
        muted
        className="absolute w-full h-full object-cover"
      >
        <source src="/hero-video.mp4" type="video/mp4" />
      </video>
      <div className="absolute inset-0 bg-black bg-opacity-50" />
      <div className="relative z-10 text-center">
        <Image
          src="/gurukilli-logo.png"
          alt="Gurukilli Logo"
          width={200}
          height={200}
          className="mx-auto mb-8"
        />
        <h1 className="text-6xl font-bold mb-4">Learn Smarter, Not Harder!</h1>
        <p className="text-2xl mb-8">Gamified learning for Std X students</p>
        <div className="flex justify-center space-x-4">
          <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105 flex items-center">
            <Play className="mr-2" size={20} />
            Start Learning
          </button>
          <button className="bg-transparent border-2 border-white hover:bg-white hover:text-purple-900 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
            Explore Features
          </button>
        </div>
      </div>
    </section>
  )
}

