import Image from 'next/image'

interface SubjectCardProps {
  subject: {
    name: string
    progress: number
    image: string
  }
}

export default function SubjectCard({ subject }: SubjectCardProps) {
  return (
    <div className="bg-purple-800 rounded-lg overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105">
      <div className="relative h-48">
        <Image
          src={subject.image}
          alt={subject.name}
          layout="fill"
          objectFit="cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <h3 className="text-2xl font-bold text-white">{subject.name}</h3>
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-semibold">Progress</span>
          <span className="text-lg font-semibold">{subject.progress}%</span>
        </div>
        <div className="w-full bg-purple-200 rounded-full h-2.5">
          <div
            className="bg-purple-600 h-2.5 rounded-full"
            style={{ width: `${subject.progress}%` }}
          ></div>
        </div>
        <button className="mt-6 w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
          Explore Topics
        </button>
      </div>
    </div>
  )
}

