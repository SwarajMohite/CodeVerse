'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import Image from 'next/image'

const subjects = [
  { name: 'Mathematics', image: '/math-bg.jpg', color: 'from-blue-500 to-cyan-500' },
  { name: 'Science', image: '/science-bg.jpg', color: 'from-green-500 to-teal-500' },
  { name: 'Social Science', image: '/social-bg.jpg', color: 'from-yellow-500 to-orange-500' },
  { name: 'Languages', image: '/language-bg.jpg', color: 'from-red-500 to-pink-500' },
  { name: 'Computer Applications', image: '/computer-bg.jpg', color: 'from-indigo-500 to-purple-500' },
  { name: 'Environmental Studies', image: '/environment-bg.jpg', color: 'from-green-600 to-lime-500' },
]

export default function SubjectShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSubject = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % subjects.length)
  }

  const prevSubject = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + subjects.length) % subjects.length)
  }

  return (
    <section className="py-16 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold mb-8 text-center">Explore Subjects</h2>
        <div className="relative">
          <button
            onClick={prevSubject}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full p-2 z-10"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={nextSubject}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full p-2 z-10"
          >
            <ChevronRight size={24} />
          </button>
          <div className="flex transition-transform duration-300 ease-in-out" style={{ transform: `translateX(-${currentIndex * 100}%)` }}>
            {subjects.map((subject, index) => (
              <div key={subject.name} className="w-full flex-shrink-0 px-4">
                <div className={`bg-gradient-to-r ${subject.color} rounded-lg overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105`}>
                  <div className="relative h-64">
                    <Image
                      src={subject.image}
                      alt={subject.name}
                      layout="fill"
                      objectFit="cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <div className="text-center">
                        <h3 className="text-3xl font-bold mb-4">{subject.name}</h3>
                        <button className="bg-white text-purple-900 font-bold py-2 px-4 rounded-full hover:bg-purple-100 transition duration-300">
                          Start Learning
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

