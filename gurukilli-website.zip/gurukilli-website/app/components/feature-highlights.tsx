import { Book, Users, PieChart, Bot, Video, Smile } from 'lucide-react'

const features = [
  { name: 'Gamified Mastery Levels', icon: PieChart, description: 'Track your progress with fun achievements' },
  { name: 'AI Study Buddy', icon: Bot, description: 'Get instant help from our smart AI assistant' },
  { name: 'Peer-to-Peer Tutorials', icon: Users, description: 'Learn from and teach your classmates' },
  { name: 'Real-Time Polling and Feedback', icon: PieChart, description: 'Engage in interactive class discussions' },
  { name: 'Mindfulness Exercises', icon: Smile, description: 'Take breaks with guided relaxation techniques' },
  { name: 'Virtual Classrooms', icon: Video, description: 'Attend live classes from anywhere' },
]

export default function FeatureHighlights() {
  return (
    <section className="py-16 bg-purple-800">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold mb-12 text-center">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div key={feature.name} className="bg-purple-700 rounded-lg p-6 shadow-lg transform transition-all duration-300 hover:scale-105 hover:bg-purple-600">
              <feature.icon className="w-12 h-12 mb-4 text-purple-300" />
              <h3 className="text-xl font-semibold mb-2">{feature.name}</h3>
              <p className="text-purple-200">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

