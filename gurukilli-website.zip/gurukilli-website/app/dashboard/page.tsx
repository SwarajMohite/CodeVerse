'use client'

import { useState } from 'react'
import EnrolledCourses from '../components/enrolled-courses'
import ProgressTracker from '../components/progress-tracker'
import RecommendedTopics from '../components/recommended-topics'
import AIChatbot from '../components/ai-chatbot'

export default function StudentDashboard() {
  const [activeTab, setActiveTab] = useState('courses')

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold mb-12 text-center">Student Dashboard</h1>
        <div className="flex justify-center mb-8">
          <button
            className={`px-4 py-2 rounded-l-full ${activeTab === 'courses' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('courses')}
          >
            Enrolled Courses
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'progress' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('progress')}
          >
            Progress Tracker
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'recommended' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('recommended')}
          >
            Recommended Topics
          </button>
          <button
            className={`px-4 py-2 rounded-r-full ${activeTab === 'chatbot' ? 'bg-purple-600' : 'bg-purple-800'}`}
            onClick={() => setActiveTab('chatbot')}
          >
            AI Chatbot
          </button>
        </div>
        {activeTab === 'courses' && <EnrolledCourses />}
        {activeTab === 'progress' && <ProgressTracker />}
        {activeTab === 'recommended' && <RecommendedTopics />}
        {activeTab === 'chatbot' && <AIChatbot />}
      </div>
    </div>
  )
}

